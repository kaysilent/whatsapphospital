module.exports=[64522,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_webhooks_route_actions_0pfz9b0.js.map