module.exports=[38448,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_account_transfer-ownership_route_actions_01hk4y4.js.map