var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/templates/submit/route.js")
R.c("server/chunks/src_lib_whatsapp_meta-api_ts_0npmyex._.js")
R.c("server/chunks/[root-of-the-server]__0hrho9c._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_whatsapp_templates_submit_route_actions_17jl9tt.js")
R.m(39438)
module.exports=R.m(39438).exports
