var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/test-key/route.js")
R.c("server/chunks/[root-of-the-server]__210c8t3._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_test-key_route_actions_1ga0lo-.js")
R.m(32036)
module.exports=R.m(32036).exports
