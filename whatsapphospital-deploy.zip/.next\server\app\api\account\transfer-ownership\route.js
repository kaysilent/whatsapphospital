var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/transfer-ownership/route.js")
R.c("server/chunks/[root-of-the-server]__0xi1i_g._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_account_transfer-ownership_route_actions_01hk4y4.js")
R.m(45411)
module.exports=R.m(45411).exports
