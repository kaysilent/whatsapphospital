module.exports=[98131,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_templates_sync_route_actions_1vz5yph.js.map