module.exports=[69123,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_account_invitations_route_actions_0rvlkuj.js.map