var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/knowledge/fetch-url/route.js")
R.c("server/chunks/[root-of-the-server]__17vocm7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_knowledge_fetch-url_route_actions_0shlcqh.js")
R.m(15984)
module.exports=R.m(15984).exports
