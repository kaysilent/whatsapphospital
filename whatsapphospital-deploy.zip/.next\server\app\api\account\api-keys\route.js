var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/api-keys/route.js")
R.c("server/chunks/[root-of-the-server]__0cwpq6c._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_account_api-keys_route_actions_10cq8nw.js")
R.m(68739)
module.exports=R.m(68739).exports
