module.exports=[57684,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_test-key_route_actions_1ga0lo-.js.map