module.exports=[57194,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("div",{className:"flex min-h-screen items-center justify-center bg-background px-4",children:a})},"metadata",0,{referrer:"no-referrer",robots:{index:!1,follow:!1}}])},36001,a=>{a.n(a.i(57194))}];

//# sourceMappingURL=src_app_join_layout_tsx_1npve1x._.js.map