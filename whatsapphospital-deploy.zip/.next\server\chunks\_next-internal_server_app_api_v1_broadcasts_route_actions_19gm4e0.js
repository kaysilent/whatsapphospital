module.exports=[86320,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_broadcasts_route_actions_19gm4e0.js.map