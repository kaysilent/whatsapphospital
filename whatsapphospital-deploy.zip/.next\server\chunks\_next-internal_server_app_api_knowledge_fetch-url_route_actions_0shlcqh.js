module.exports=[7891,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_knowledge_fetch-url_route_actions_0shlcqh.js.map