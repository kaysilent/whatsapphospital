globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/V7k_Sv1tS3DbkLl79WxST/_buildManifest.js",
    "static/V7k_Sv1tS3DbkLl79WxST/_ssgManifest.js",
    "static/V7k_Sv1tS3DbkLl79WxST/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/36ssnkm0cjgq6.js",
    "static/chunks/2f7zsxgsvrylb.js",
    "static/chunks/3zlwld519rxgj.js",
    "static/chunks/03zaloxt0wx--.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/turbopack-1b5ehk3bpji5-.js"
  ]
};
