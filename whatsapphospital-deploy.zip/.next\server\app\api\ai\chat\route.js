var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/chat/route.js")
R.c("server/chunks/[root-of-the-server]__1dsxqmp._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_chat_route_actions_0ki7zfv.js")
R.m(23316)
module.exports=R.m(23316).exports
