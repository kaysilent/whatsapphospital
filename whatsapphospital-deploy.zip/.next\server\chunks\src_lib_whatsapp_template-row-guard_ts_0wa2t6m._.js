module.exports=[86666,t=>{"use strict";t.s(["isMessageTemplate",0,function(t){return!!t&&"object"==typeof t&&"string"==typeof t.id&&"string"==typeof t.user_id&&"string"==typeof t.name&&"string"==typeof t.body_text}])}];

//# sourceMappingURL=src_lib_whatsapp_template-row-guard_ts_0wa2t6m._.js.map