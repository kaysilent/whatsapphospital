module.exports=[40068,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_contacts_%5Bid%5D_tags_route_actions_1tmfnma.js.map