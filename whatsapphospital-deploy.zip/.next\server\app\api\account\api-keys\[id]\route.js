var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/api-keys/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1ome79a._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_account_api-keys_[id]_route_actions_0lpz0_c.js")
R.m(24218)
module.exports=R.m(24218).exports
