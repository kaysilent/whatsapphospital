var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/automations/[id]/duplicate/route.js")
R.c("server/chunks/[root-of-the-server]__0-shrhr._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_automations_[id]_duplicate_route_actions_1r4k27x.js")
R.m(50700)
module.exports=R.m(50700).exports
