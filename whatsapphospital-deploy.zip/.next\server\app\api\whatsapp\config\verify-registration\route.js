var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/config/verify-registration/route.js")
R.c("server/chunks/[root-of-the-server]__1n8t6es._.js")
R.c("server/chunks/src_lib_whatsapp_meta-api_ts_0npmyex._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/1oeh_server_app_api_whatsapp_config_verify-registration_route_actions_1jndcnb.js")
R.m(25513)
module.exports=R.m(25513).exports
