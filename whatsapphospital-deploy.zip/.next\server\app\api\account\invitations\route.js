var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/invitations/route.js")
R.c("server/chunks/[root-of-the-server]__1o5lfx9._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_account_invitations_route_actions_0rvlkuj.js")
R.m(74084)
module.exports=R.m(74084).exports
