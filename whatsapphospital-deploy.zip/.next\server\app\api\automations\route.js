var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/automations/route.js")
R.c("server/chunks/src_lib_whatsapp_meta-api_ts_0npmyex._.js")
R.c("server/chunks/[root-of-the-server]__19dvjx-._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_automations_route_actions_00ccc3d.js")
R.m(63773)
module.exports=R.m(63773).exports
