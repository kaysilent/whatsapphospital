module.exports=[15455,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_config_route_actions_1q62-dr.js.map