var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0enaloi._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0domq1v._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_logout_route_actions_0regwyr.js")
R.m(83932)
module.exports=R.m(83932).exports
