var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/account/members/route.js")
R.c("server/chunks/[root-of-the-server]__0wtp0z6._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_account_members_route_actions_1nq1zcx.js")
R.m(80563)
module.exports=R.m(80563).exports
