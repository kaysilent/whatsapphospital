var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/invitations/[token]/peek/route.js")
R.c("server/chunks/[root-of-the-server]__0qhehi1._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_invitations_[token]_peek_route_actions_13z0-c5.js")
R.m(99815)
module.exports=R.m(99815).exports
