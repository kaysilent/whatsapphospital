module.exports=[90025,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_account_invitations_%5Bid%5D_route_actions_19_qavw.js.map