module.exports=[13384,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_invitations_%5Btoken%5D_peek_route_actions_13z0-c5.js.map