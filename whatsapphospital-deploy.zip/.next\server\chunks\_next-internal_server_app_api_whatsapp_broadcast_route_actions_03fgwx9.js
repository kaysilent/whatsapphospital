module.exports=[90061,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_broadcast_route_actions_03fgwx9.js.map