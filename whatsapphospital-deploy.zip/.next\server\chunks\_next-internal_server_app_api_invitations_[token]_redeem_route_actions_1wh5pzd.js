module.exports=[6280,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_invitations_%5Btoken%5D_redeem_route_actions_1wh5pzd.js.map