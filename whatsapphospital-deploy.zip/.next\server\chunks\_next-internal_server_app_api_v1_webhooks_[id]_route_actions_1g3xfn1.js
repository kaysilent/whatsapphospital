module.exports=[74595,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_webhooks_%5Bid%5D_route_actions_1g3xfn1.js.map