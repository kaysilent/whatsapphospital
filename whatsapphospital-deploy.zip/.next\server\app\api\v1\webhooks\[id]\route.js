var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/webhooks/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__06ynijb._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_webhooks_[id]_route_actions_1g3xfn1.js")
R.m(70670)
module.exports=R.m(70670).exports
