module.exports=[12437,a=>{a.v(b=>Promise.all(["server/chunks/ssr/messages_en_json_[json]_cjs_206072-._.js"].map(b=>a.l(b))).then(()=>b(45983)))}];

//# sourceMappingURL=messages_en_json_%5Bjson%5D_cjs_1vtm5rs._.js.map