var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/broadcasts/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1pcknzd._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_broadcasts_[id]_route_actions_0_11u8s.js")
R.m(62491)
module.exports=R.m(62491).exports
