var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/quick-replies/[id]/route.js")
R.c("server/chunks/src_lib_whatsapp_meta-api_ts_0npmyex._.js")
R.c("server/chunks/[root-of-the-server]__0r-1ono._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/_next-internal_server_app_api_quick-replies_[id]_route_actions_0kk8ypi.js")
R.m(39377)
module.exports=R.m(39377).exports
