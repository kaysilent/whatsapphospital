var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/v1/webhooks/route.js")
R.c("server/chunks/[root-of-the-server]__0t4zn5e._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_v1_webhooks_route_actions_0pfz9b0.js")
R.m(80187)
module.exports=R.m(80187).exports
