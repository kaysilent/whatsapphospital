var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/templates/sync/route.js")
R.c("server/chunks/[root-of-the-server]__1u0n-ep._.js")
R.c("server/chunks/node_modules_0bucrdp._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_whatsapp_templates_sync_route_actions_1vz5yph.js")
R.m(73632)
module.exports=R.m(73632).exports
