:HL["/_next/static/chunks/231f26yosnyz6.css","style"]
:HL["/_next/static/chunks/2agej8kya0v6q.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"V7k_Sv1tS3DbkLl79WxST"}
