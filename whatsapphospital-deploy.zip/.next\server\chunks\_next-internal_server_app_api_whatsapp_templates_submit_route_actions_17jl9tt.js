module.exports=[79293,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_templates_submit_route_actions_17jl9tt.js.map