var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/automations/cron/route.js")
R.c("server/chunks/src_lib_whatsapp_meta-api_ts_0npmyex._.js")
R.c("server/chunks/src_lib_automations_engine_ts_0-p64u-._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__1mk_kwa._.js")
R.c("server/chunks/_next-internal_server_app_api_automations_cron_route_actions_1kpy2x_.js")
R.m(54683)
module.exports=R.m(54683).exports
