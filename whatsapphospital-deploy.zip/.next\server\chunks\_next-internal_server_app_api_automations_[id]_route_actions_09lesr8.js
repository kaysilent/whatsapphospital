module.exports=[28306,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_automations_%5Bid%5D_route_actions_09lesr8.js.map